<?php

return [
    'name' => 'LandingPage'
];
